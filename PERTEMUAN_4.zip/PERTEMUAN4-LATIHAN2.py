a = int(input("Insert number "))
for a in range (a, 0, -1):
    print (str(a) * a )
for a in range (2, a+3, +1):
    print(str(a)*a)
    
