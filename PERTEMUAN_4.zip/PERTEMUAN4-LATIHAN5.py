grades = {
    "A": 4,
    "A-": 3.75,
    "B+" : 3.50,
    "B" : 3.00,
    "B-" : 2.75,
    "C+" : 2.50,
    "C" : 2.00,
    "C-" : 1.75,
    "D" : 1.50,
    "E" : 1.20
}
score = {
    4:"A", 3.75:"A-", 3.50:"B+", 3.00:"B", 2.75:"B-", 2.5:"C+", 2.00:"C", 
    1.75:"C-", 1.50:"D", 1.20:"E"}

r = 0
g = 0
while (True):
    i=str(input("Enter Grade Category (Press Enter to Stop):"))
    
    if (i==""):
        avg = g/r
        print("The average grade is",avg,"with a designation of",score[avg])
        break
    else:
        print(grades[i])
        r = r+1
        g = g + int(grades[i])
