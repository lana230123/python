
while (True):
    varA = int(input("insert number: "))
    if (varA%2 == 0):
        print("even")
    else:
        print("odd")
        
    varYN = str(input("Would you like to try again (Y/N)"))
    
    if (varYN=="Y"):
        continue
    elif (varYN=="N"):
        print("Thank you for using my program ^^")
        break
    else:
        print ("invput invalid")
