#program konversi suhu

print("1.Celsius to Fahrenheit \n2.Celsius to Kelvin \n3.Fahrenheit to Celsius \n4.Fahrenheit to Kelvin \n5.Kelvin to Celsius \n6.Kelvin to Fahrenheit")

konversi = int(input("pilih konversi: "))

if (konversi==1 or konversi== 2 ):
    temp = float(input("input celcius"))
    if (konversi==1):
        temp = (temp*9/5)+32
        print(temp,"dalam farenheit")
    else:
        temp = temp +273.15
        print (temp, "dalam kelvin")
      
elif (konversi==3 or konversi==4):
    temp = float(input("input farenheit: "))
    if (konversi ==3 ):
        temp = (temp-32)*(5/9)
        print(temp, "dalam celcius")
    else:
        temp = (temp-32)*(5/9) + 273.15
        print (temp, "dalam kelvin")
elif (konversi==5 or konversi==6):
    temp = float(input("input kelvin: "))
    if (konversi == 5 ):
        temp = temp-273.15
        print (temp,"dalam celcius")
    else:
        temp= (temp-273.15)*(9/5)+32
        print (temp, "dalam farenheit")
