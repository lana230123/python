varA = int(input("insert number: "))

if (varA%2 == 0):
    print("even")
else:
    print("odd")
