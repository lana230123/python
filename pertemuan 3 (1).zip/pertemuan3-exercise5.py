import math
a = (int(input("nilai a")))
b = (int(input("nilai b")))
c = (int(input("nilai c")))

discriminant = b**2 - (4*a*c)

if (a==0):
    print("It is not a quadratic equation")
elif (discriminant>=0):
    root1 = ((-b+math.sqrt(discriminant))/2*a)
    root2 = ((-b-math.sqrt(discriminant))/2*a)
    print(a,"x^2 +",b,"x +",c)
    if (discriminant>0):
        print("it has disinct roots", root1,"and", root2)
    elif (discriminant == 0):
            print("it has one root", root1)
else:
    print("it has imaginary roots")
    print(discriminant)
    print("roots = ((-b±√(b**2 - (4*a*c)))/2*a)")