age = int(input("Input age:"))
if (age<0):
    print("age invalid")
    age = int(input("Input age:"))
elif (0<=age<=1):
    print("baby")
elif (2<=age<=3):
    print("toddler")
elif (4<=age<=5):
    print("preschooler")
elif (6<=age<=12):
    print("child")
elif (13<=age<=17):
    print("teenager")
elif (18<=age<=21):
    print("young adult")
elif (22<=age<=30):
    print("pre-adult")
elif (31<=age<=50):
    print("adult")
elif (51<=age<=70):
    print("pre-elderly")
elif (age>71):
    print("elderly")
