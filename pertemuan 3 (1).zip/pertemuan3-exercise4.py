
print ("input 3 sisi segitiga")
input1 = int(input("sisi pertama: "))
input2 = int(input("sisi kedua: "))
input3 = int(input("sisi ketiga: "))
#mementukan urutan panjang sisi

if (input1<=input2<=input3):
     a = input1
     b = input2
     c = input3
elif (input2<=input1<=input3):
     b =input1
     a =input2
     c = input3
elif (input3<=input2<=input1):
     c =input1
     b =input2
     a = input3


if (a+b<=c) :
    print("Not a triangle")
else:
    if ( a==b==c ):
        print("equilateral")
    elif (a==b or b==c or a==b):
        print("isosceles")
    elif ((a**2 + b**2)== (c**2)):
        print ("right angle")
    else:
        print("scalene")
